<?php 


define("DB_HOST", "localhost");

define("DB_USER", "root");

define("DB_PASS", "root");

define("DB_NAME", "blogtrial");







?>
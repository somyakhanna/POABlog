        <div class="grid_12">
             <ul class="nav main">
                <li class="ic-dashboard"><a href="index.html"><span>Dashboard</span></a> </li>
                <li class="ic-form-style"><a href=""><span>User Profile</span></a></li>
                <li class="ic-typography"><a href="changepassword.html"><span>Change Password</span></a></li>
                <li class="ic-grid-tables"><a href="inbox.html"><span>Inbox</span></a></li>
                <li class="ic-charts"><a href="postlist.html"><span>Visit Website</span></a></li>
            </ul>
        </div>
        <div class="clear">
        </div>
           <div class="grid_2">
            <div class="box sidemenu">
                <div class="block" id="section-menu">
                    <ul class="section menu">
                        <li><a class="menuitem">Site Option</a>
                            <ul class="submenu">
                                <li><a href="titleslogan.html">Title & Slogan</a></li>
                                <li><a href="social.html">Social Media</a></li>
                                <li><a href="copyright.html">Copyright</a></li>
                                
                            </ul>
                        </li>
                        
                         <li><a class="menuitem">Update Pages</a>
                            <ul class="submenu">
                                <li><a>About Us</a></li>
                                <li><a>Contact Us</a></li>
                            </ul>
                        </li>
                        <li><a class="menuitem">Category Option</a>
                            <ul class="submenu">
                               <li><a href="addcat.php">Add Category</a> </li>
                                <li><a href="catlist.php">Category List</a> </li>
                            </ul>
                        </li>
                        <li><a class="menuitem">Post Option</a>
                            <ul class="submenu">
                                 <li><a href="addpost.php">Add Post</a> </li>
                                <li><a href="postlist.php">Post List</a> </li>
                                 <li><a href="editpost.php">Edit Post</a> </li>
                                <li><a href="deletepost.php">Delete List</a> </li>
                            </ul>
                        </li>
                        <li><a class="menuitem">admin </a>
                            <ul class="submenu">
                                <li><a href="addadmin.php">Add admin</a> </li>
                                <li><a href="viewadmin.php">View admin</a> </li>
                                <li><a href="admindel.php">Delete admin</a> </li>
                                
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
